#!/bin/bash

#Files a backup
backup_file=""

#Variables de destino
dest=""

#Ayuda
ayuda () 
{
	echo "-o para el directorio de origen"
	echo "-d para el directorio de destino"
	echo "-h para ayuda"
	exit 1
}

#Opciones de comando
while getopts "o:d:h" opt; do
	case $opt in
	o) backup_file="$OPTARG"
	;;
	d) dest="$OPTARG"
	;;
	h) ayuda
	;;
	esac
done

if [-z "$backup_file"] || [-z "$dest"]; then
	echo "no se especifico directorio de origen y destino"
	ayuda
fi

if [! -d "$backup_file"] || [! -d "$dest"]; then
	echo "los directorios especificados no existen"
	exit 1
fi

#Crear nombre del archivo "ANSI"
day=$(date "+%Y%m%d")
time=$(date "+%H:%M:%S")
archivo="$(basename $backup_file)_bkp_$day.tar.gz"

#Log
log(){
	local texto="$1"
	echo "$day - $time - $texto" >> "var/log/backup_full.log"
}

#Print banner estado
echo "Realizando backup"
echo 

#Realizar backup y log
log "Realizando Backup para $backup_file a destino $dest"
tar czf "$dest/$archivo" "$backup_file"

#Enviar mail
if [-s /tmp/backup_full.log]; then
	mutt -s "Copia de seguridad del log" -a /var/log/backup_full.log -- root
fi

#Print banner finalizado
echo "Backup Finalizado"
