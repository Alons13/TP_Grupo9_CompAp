#!/bin/bash
# Cual fue el primer dia del mes
primerDiaDelMes() {
  fecha="$1"
  dia=$(date -d "$fecha" +%d)
  mes=$(date -d "$fecha" +%m)
  anio=$(date -d "$fecha" +%Y)

  #que dia cayo el primer dia del mes
  primerDia=$(date -d "$anio-$mes-01" +%u)

  echo "$primerDia"
}

# Función es el segundo lunes del mes
esSegundoLunes() {
  fecha="$1"
  dia=$(date -d "$fecha" +%d)
  #que dia cayo el primer dia del mes
  primerDia=$(primerDiaDelMes "$fecha")

  #que dia es el tercer lunes
  if [ $primerDia -eq 1 ]; then
    segundoLunes=8
  else
    segundoLunes=$((15 - $primerDia + 1))
  fi

  if [ "$dia" == "$segundoLunes" ]; then
    echo 0 #es el tercer lunes
  fi
}

# Funccion es el tercer lunes del mes
esTercerLunes() {
  fecha="$1"
  dia=$(date -d "$fecha" +%d)
  #que dia cayo el primer dia del mes
  primerDia=$(primerDiaDelMes "$fecha")

  #que dia es el tercer lunes
  if [ $primerDia -eq 1 ]; then
    tercerLunes=15
  else
    tercerLunes=$((22 - $primerDia + 1))
  fi

  if [ "$dia" == "$tercerLunes" ]; then
    echo 0 #es el tercer lunes
  fi
}

esCuartoLunes() {
  fecha="$1"
  dia=$(date -d "$fecha" +%d)
  #que dia cayo el primer dia del mes
  primerDia=$(primerDiaDelMes "$fecha")

  #que dia es el cuarto lunes
  if [ $primerDia -eq 1 ]; then
    cuartoLunes=22
  else
    cuartoLunes=$((29 - $primerDia + 1))
  fi

  if [ "$dia" == "$cuartoLunes" ]; then
    echo 0 #es el cuarto lunes
  fi
}

# Función
esLaborable() {
  fecha="$1"
  dia=$(date -d "$fecha" +%d)
  mes=$(date -d "$fecha" +%m)
  anio=$(date -d "$fecha" +%Y)
  semana=$(date -d "$fecha" +%u)

  # Verificar fin de semana
  if [ $semana -eq 6 ] || [ $semana -eq 7 ]; then
    echo "El Dia =$fecha no es laborable. Es fin de semana"
    return 1
  fi

  #FERIADOS
  feriados=("01-01:Año Nuevo" "02-20:Carnaval" "02-21:Carnaval" "03-24:Día Nacional de la Memoria por la Verdad y la Justicia" "03-23: Viernes Santo" "04-02: Día del Veterano y de los Caídos en la Guerra de Malvinas" "05-01: Día del Trabajo" "05-25: Día de la Revolución de Mayo" "06-20: Paso a la Inmortalidad del General D. Manuel Belgrano" "07-09: Día de la Independencia" "08-17: Paso a la Inmortalidad del General D. José de San Martín" "10-12: Día del Respeto a la Diversidad Cultural" "11-20: Día de la Soberanía Nacional" "12-08: Día de la Inmaculada Concepción de María" "12-25: Navidad")

  # Verificar si es un feriado
  for feriado in "${feriados[@]}"; do
    fechaFeriado="${feriado%%:*}"
    explicacion="${feriado#*:}"

    #feriados inamovibles
    if [ "$mes-$dia" == "$fechaFeriado" ]; then
      echo "La fecha $fecha es un feriado. No es laborable. Porque $explicacion."
      return 1
    fi
    esTercerLunes "$fecha"
    resultado=$?
    if [ "$resultado" -eq 0 ] && [ "$mes" == 6 ]; then
      echo "La fecha $fecha es un feriado. No es laborable. Porque es el Paso a la Inmortalidad del General D. Manuel Belgrano"	
      return 1
    #el feriado del 17 de agosto se pasa al tercer lunes del mes
    elif [ "$resultado" -eq 0 ] && [ "$mes" == 8 ]; then
      echo "La fecha $fecha es un feriado. No es laborable. Porque es el Paso a la Inmortalidad del General D. José de San Martín"	
      return 1
    #el feriado del 12 de octubre se pasa al segundo lunes del mes
    esSegundoLunes "$fecha"
    resultado=$?
    elif [ "$resultado" -eq 0 ] && [ "$mes" == 10 ]; then
      echo "La fecha $fecha es un feriado. No es laborable. Porque es el Día del Respeto a la Diversidad Cultural"
      return 1
    #el feriado del 20 de noviembre se pasa al cuarto lunes del mes
    esCuartoLunes "$fecha"
    resultado=$?
    elif [ "$resultado" -eq 0 ] && [ "$mes" == 11 ]; then
      echo "La fecha $fecha es un feriado. No es laborable. Porque es el Día de la Soberanía Nacional"
      return 1
    fi
  done

  # Laborable
  echo "La fecha $fecha es laborable."
  return 0
}
