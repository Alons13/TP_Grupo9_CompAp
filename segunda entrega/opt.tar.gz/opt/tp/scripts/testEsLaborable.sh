source esLaborable.sh

esLaborable "2023-01-02"
esLaborable "2023-08-29"
esLaborable "2023-10-09"
esLaborable "2023-11-19"
